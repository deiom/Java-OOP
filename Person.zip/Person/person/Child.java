package OOP.Inheritance.Person.person;

import OOP.Inheritance.Person.person.Person;

public class Child extends Person {
    public Child(String name, int age){
        super(name,age);
    }
}
